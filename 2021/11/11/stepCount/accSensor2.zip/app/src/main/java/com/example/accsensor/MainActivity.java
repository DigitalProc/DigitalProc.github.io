 package com.example.accsensor;

 import android.Manifest;
 import android.app.Activity;
 import android.content.Context;
 import android.content.pm.PackageManager;
 import android.hardware.Sensor;
 import android.hardware.SensorEvent;
 import android.hardware.SensorEventListener;
 import android.hardware.SensorManager;
 import android.os.Build;
 import android.os.Bundle;
 import android.os.Environment;
 import android.util.Log;
 import android.view.View;
 import android.widget.ImageView;
 import android.widget.TextView;
 import android.widget.Toast;

 import androidx.annotation.NonNull;
 import androidx.core.app.ActivityCompat;
 import java.io.File;
 import java.io.FileWriter;
 import java.io.IOException;
 import java.text.SimpleDateFormat;

 public class MainActivity extends Activity implements SensorEventListener {
     private float mLastX, mLastY, mLastZ;
     private FileWriter writer = null;
     private boolean mInitialized; private SensorManager mSensorManager; private Sensor mAccelerometer; private final float NOISE = (float) 3;
     /** Called when the activity is first created. */
     //读写权限
     private static String[] PERMISSIONS_STORAGE = {
             Manifest.permission.READ_EXTERNAL_STORAGE,
             Manifest.permission.WRITE_EXTERNAL_STORAGE};
     //请求状态码
     private static int REQUEST_PERMISSION_CODE = 1;


     @Override
    //创建app的时候会调用的方法
     public void onCreate(Bundle savedInstanceState) {
         super.onCreate(savedInstanceState);
         // 设定这个方法的布局是activitu_main.xml布局
         setContentView(R.layout.activity_main);
         // 这是一个私有的变量，用于表示加速度传感器是否已经被初始化
         mInitialized = false;
         // 调用加速度传感器
         // 首先启用传感器服务
         mSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
         // 调用传感器服务中的加速度传感服务
         mAccelerometer = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
         // 调用加速度传感服务中的监听器，最后一个参数决定了传感器的灵敏度，有多种可以调的范围
         mSensorManager.registerListener(this, mAccelerometer, SensorManager.SENSOR_DELAY_FASTEST);
         // 绑定写入按钮的功能
         findViewById(R.id.btn1).setOnClickListener(new View.OnClickListener(){
             @Override
             public void onClick(View v){
                 // 判断是否有读写的权限，并且请求相关的权限
                 String[] PERMISSIONS = {android.Manifest.permission.READ_EXTERNAL_STORAGE,android.Manifest.permission.WRITE_EXTERNAL_STORAGE};
                 // 如果权限不够，就请求权限
                 if (!hasPermissions(mContext, PERMISSIONS)) {
                     ActivityCompat.requestPermissions((Activity) mContext, PERMISSIONS, REQUEST );
                 } else {
                     //do here
                     try {
                         // 根据当前时间生成一个文件名
                         long time = System.currentTimeMillis();
                         SimpleDateFormat sd1 = new SimpleDateFormat("mm-ss-SSS");
                         String sFileName = sd1.format(time)+".csv";
                        // 创建一个可写入的文件句柄，并且使用私有变量存储，写入的位置在"/Document/acc_data/"，进入文件管理器就可以找到
                         writer = writeTextFile(sFileName,"acc_data");
                        // 提示文件开始读写
                         Toast.makeText(MainActivity.this, "开始写文件", Toast.LENGTH_SHORT).show();
                     } catch (IOException e) {
                         e.printStackTrace();
                     }
                 }
             }
         });
         // 绑定停止文件写入按钮的功能
         findViewById(R.id.btn2).setOnClickListener(new View.OnClickListener(){
            // 写入点击的功能
             @Override
             public void onClick(View v){
                 // 如果有句柄，就关闭
                 if (writer != null){
                     try {
                         writer.flush();
                         writer.close();
                         writer = null;
                         Log.i("Success close:", "writer is null!");
                         Toast.makeText(MainActivity.this, "停止写文件", Toast.LENGTH_SHORT).show();
                     } catch (IOException e) {
                         e.printStackTrace();
                     }
                 }else {
                     Toast.makeText(MainActivity.this, "没有打开的文件", Toast.LENGTH_SHORT).show();
                 }
             }
         });
         // 在开始创建的时候，检查一遍写入的权限
         if (Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP) {
             if (ActivityCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                 ActivityCompat.requestPermissions(this, PERMISSIONS_STORAGE, REQUEST_PERMISSION_CODE);
             }
         }
         }

     // 当从后台调出软件的时候会调用的方法
     protected void onResume() {
         super.onResume();
         mSensorManager.registerListener(this, mAccelerometer, SensorManager.SENSOR_DELAY_NORMAL);
     }
     // 当软件暂停的时候会调用的方法
     protected void onPause() {
         super.onPause();
         mSensorManager.unregisterListener(this);
     }

     @Override
     public void onAccuracyChanged(Sensor sensor, int accuracy) {
    // can be safely ignored for this demo
     }


     @Override
     // 针对传感器调用的方法
     // 虽然这个自带函数的名字叫“onSensorChanged”，但是并不是只有在传感器数值改变的时候才调用这个方法，而是持续调用
     public void onSensorChanged(SensorEvent event) {
         // 获取当前布局文件中的时间文本框
         TextView tvTime = (TextView)findViewById(R.id.time);
         // 获取当前的系统时间句柄
         long time = System.currentTimeMillis();
         // 规范时间的格式
         SimpleDateFormat sd1 = new SimpleDateFormat("mm, ss, SSS");
         String time_stamp = sd1.format(time);
         // 显示时间
         tvTime.setText(time_stamp);
         // 获取布局文件中显示三个方向加速度数值的文本框
         TextView tvX= (TextView)findViewById(R.id.x_axis);
         TextView tvY= (TextView)findViewById(R.id.y_axis);
         TextView tvZ= (TextView)findViewById(R.id.z_axis);
         // 获取显示图片的图片框
         ImageView iv = (ImageView)findViewById(R.id.image);
         float x = event.values[0];
         float y = event.values[1];
         float z = event.values[2];
         // 初始化，将所有数值置0
         if (!mInitialized) {
             mLastX = x;
             mLastY = y;
             mLastZ = z;
             tvX.setText("0.0");
             tvY.setText("0.0");
             tvZ.setText("0.0");
             mInitialized = true;
         } else {
             // 计算变化量
             float deltaX = Math.abs(mLastX - x);
             float deltaY = Math.abs(mLastY - y);
             float deltaZ = Math.abs(mLastZ - z);
             // 过滤噪声
             if (deltaX < NOISE) deltaX = (float)0.0;
             if (deltaY < NOISE) deltaY = (float)0.0;
             if (deltaZ < NOISE) deltaZ = (float)0.0;
             // 存储当前加速度传感器的数值
             mLastX = x;
             mLastY = y;
             mLastZ = z;
             // 显示当前加速度传感器的数值
             tvX.setText(Float.toString(x));
             tvY.setText(Float.toString(y));
             tvZ.setText(Float.toString(z));
             // 将图片设置成可以看到的状态
             iv.setVisibility(View.VISIBLE);
             // 根据当前变化量的大小，用图片显示相应的状态
             if (deltaX > deltaY) {
                 iv.setImageResource(R.drawable.horizontal);
             } else if (deltaY > deltaX) {
                 iv.setImageResource(R.drawable.vertical);
             } else {
                 // 如果都是0，就隐藏图片
                 iv.setVisibility(View.INVISIBLE);
             }
             // 写文件
             if (writer != null){
                 try {
                     writer.append(time_stamp+", "+x+", "+y+", "+z+'\n');
                 } catch (IOException e) {
                     e.printStackTrace();
                 }
             }
         }
     }

     private Context mContext=this;

     private static final int REQUEST = 112;


     @Override
     public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
         super.onRequestPermissionsResult(requestCode, permissions, grantResults);
         switch (requestCode) {
             case REQUEST: {
                 if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                     //do here
                 } else {
                     Toast.makeText(mContext, "The app was not allowed to read your store.", Toast.LENGTH_LONG).show();
                 }
             }
         }
     }
     private static boolean hasPermissions(Context context, String... permissions) {
         if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && context != null && permissions != null) {
             for (String permission : permissions) {
                 if (ActivityCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED) {
                     return false;
                 }
             }
         }
         return true;
     }
     // https://stackoverflow.com/questions/8355632/how-do-you-usually-tag-log-entries-android
     // 这是写文件的主要方法，能在公共文件区域创建文件并且完成写入操作
     public FileWriter writeTextFile(String sFileName, String sBody) throws IOException {
         // 创建一个文件句柄，根文件夹是系统自带的Documents文件夹，自己指定一个写入文件夹acc_data
         File root = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "acc_data");
        // 如果不存在root文件夹，就创建一个
         if (!root.exists()) {
             Log.i("creating right now:",root.getPath());
             // 创建文件夹
             root.mkdirs();
             Log.i("Creation was successful" , (root.exists() ? "Yes." : "No."));
         } else {
             Log.i("Path exists: ", root.getPath());
         }
        // 在这个文件夹下面创建一个文件
         File measurementFile = new File(root, sFileName);
         // 打开文件
         FileWriter writer  = new FileWriter(measurementFile);
//         writer.append(sBody);
//         writer.flush();
//         writer.close();
        // 返回一个文件句柄
         return writer;
     }
 }
